module.exports = {
    database:{
        URI : 'mongodb+srv://sepau96:tula1234@cluster0.cbseu.mongodb.net/toktik?retryWrites=true&w=majority'
    }
}

